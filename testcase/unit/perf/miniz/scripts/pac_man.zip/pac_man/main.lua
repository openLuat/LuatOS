-- Pac-Man Game Main Entry
local sys = require("sys")
log.info("pacman", "Pac-Man Game Started")
sys.taskInit(function()
    log.info("pacman", "Loading game resources...")
    sys.wait(1000)
    log.info("pacman", "Game is ready!")
end)
return { version = "1.0" }